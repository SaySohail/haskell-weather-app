{-# LANGUAGE DeriveGeneric #-}

module Types (
    Record (..),
    Records (..)
) where

import GHC.Generics
--import Database.SQLite.Simple.FromRow
import Database.SQLite.Simple.ToRow
import Data.Aeson
import Data.String.CSV

data Record = Record {
    precipitation :: Float,
    date :: String,
    month :: Int,
    week :: Int,
    year :: Int,
    city :: String,
    code :: String,
    location :: String,
    state ::  String,
    avg_temp :: Int,
    max_temp :: Int,
    min_temp :: Int,
    wind_direction :: Int,
    wind_speed :: Float
} deriving (Show, Generic)

data Records = Records {
    records :: [Record]
} deriving (Show, Generic)

instance FromNamedRecord Record where
    parseNamedRecord record = 
        Record 
        <*> record .: "Data.Precipitation"
        <*> record .: "Date.Full"
        <*> record .: "Date.Month"
        <*> record .: "Date.Week of"
        <*> record .: "Date.Year"
        <*> record .: "Station.City"
        <*> record .: "Station.Code"
        <*> record .: "Station.Location"
        <*> record .: "Station.State"
        <*> record .: "Data.Temperature.Avg Temp"
        <*> record .: "Data.Temperature.Max Temp"
        <*> record .: "Data.Temperature.Min Temp"
        <*> record .: "Data.Wind.Direction"    
        <*> record .: "Data.Wind.Speed"
