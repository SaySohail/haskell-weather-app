module Main (main) where

import System.IO()
import Fetch
import Text.CSV()

main :: IO ()
main = do
    putStrLn "---------------------------------"
    putStrLn "  Welcome to the Weather data app  "
    putStrLn "  (1) Download data              "
    putStrLn "  (2) All entries by Region     "
    putStrLn "  (3) Total cases by country     "
    putStrLn "  (4) Quit                       "
    putStrLn "---------------------------------"
    putStr "Choose an option > "
    option <- readLn :: IO Int
    case option of
        1 -> do
            let url = "https://corgis-edu.github.io/corgis/datasets/csv/weather/weather.csv"
            print "Downloading..."
            csv <- download url
            --print csv
            print "Parsing..."
            case (parseRecords csv) of
                Left err -> print err
                Right recs -> do
                    print "Printing recs..."
                    print recs
                    print "Done!"
                    quit ()
